package us.virtusa.vyntra.api;

import org.junit.Test;

import static org.junit.Assert.*;

public class CartControllerTest {

    @Test
    public void getCart() {
    }
}
