package us.virtusa.vyntra.service;

import us.virtusa.vyntra.entity.Cart;
import us.virtusa.vyntra.entity.ProductInOrder;
import us.virtusa.vyntra.entity.User;

import java.util.Collection;


public interface CartService {
    Cart getCart(User user);

    void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

    void delete(String itemId, User user);

    void checkout(User user);
}
