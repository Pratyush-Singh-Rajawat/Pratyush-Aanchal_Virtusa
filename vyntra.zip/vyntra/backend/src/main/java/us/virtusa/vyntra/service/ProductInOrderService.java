package us.virtusa.vyntra.service;

import us.virtusa.vyntra.entity.ProductInOrder;
import us.virtusa.vyntra.entity.User;


public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
