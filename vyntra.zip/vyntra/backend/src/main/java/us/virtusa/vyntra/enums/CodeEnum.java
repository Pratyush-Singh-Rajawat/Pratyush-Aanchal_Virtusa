package us.virtusa.vyntra.enums;

public interface CodeEnum {
    Integer getCode();

}
