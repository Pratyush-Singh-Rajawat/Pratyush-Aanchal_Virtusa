export enum ProductStatus {
    "Available", "Unavailable"
}
